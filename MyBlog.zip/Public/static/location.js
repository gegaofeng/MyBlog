/**
 * Created by Administrator on 16-1-10.
 */
$(function(){
        $("#storage").on("click",function(){
            window.location.href = '/index.php?s=/home/article/lists/category/storage.html';
        })
        $("#db").on("click",function(){
            window.location.href = '/index.php?s=/home/article/lists/category/db.html';
        })
        $("#cooperate").on("click",function(){
            window.location.href = '/index.php?s=/home/article/lists/category/cooperate.html';
        })
        $("#front").on("click",function(){
            window.location.href = '/index.php?s=/home/article/lists/category/front.html';
        })
    }
)
